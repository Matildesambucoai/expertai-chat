import React from 'react';
import ExpertAIChatApp from './ExpertAIChatApp';
import './App.css';

export default function App() {
  return <ExpertAIChatApp />;
}
