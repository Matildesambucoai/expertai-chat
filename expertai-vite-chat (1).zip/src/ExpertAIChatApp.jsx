
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import './App.css';

const suggestedQuestions = [
  "What does expert.ai do?",
  "How can you help me?",
  "Show me your AI tools.",
  "Why choose hybrid AI?"
];

export default function ExpertAIChatApp() {
  const [messages, setMessages] = useState([
    { sender: 'bot', text: "Hi! I’m Expert, your AI-powered guide. What would you like to know today?" }
  ]);
  const [input, setInput] = useState('');
  const [queryCount, setQueryCount] = useState(0);
  const [showLinkedIn, setShowLinkedIn] = useState(false);
  const [showTyping, setShowTyping] = useState(false);

  const handleSend = (text) => {
    const newMessages = [...messages, { sender: 'user', text }];
    setMessages(newMessages);
    setInput('');
    setQueryCount(prev => prev + 1);
    setShowTyping(true);

    setTimeout(() => {
      let reply = '';
      const lower = text.toLowerCase();
      if (lower.includes("what") || lower.includes("do you")) {
        reply = "We help organizations understand data and make informed decisions with hybrid AI.";
      } else if (lower.includes("tools")) {
        reply = "Explore our Natural Language Understanding Suite or test our tools in the Sandbox.";
      } else if (lower.includes("hybrid")) {
        reply = "Hybrid AI combines symbolic AI and machine learning for better accuracy and explainability.";
      } else {
        reply = "That’s a great question! Expert.ai uses AI to extract insights from language at scale.";
      }

      setMessages([...newMessages, { sender: 'bot', text: reply }]);
      setShowTyping(false);

      if (queryCount + 1 >= 3 && !showLinkedIn) {
        setTimeout(() => {
          setShowLinkedIn(true);
          setMessages(prev => [...prev, {
            sender: 'bot',
            text: "Great to chat with you! To continue and personalize your experience, please log in via LinkedIn."
          }]);
        }, 800);
      }
    }, 1000);
  };

  const handleSuggested = (q) => handleSend(q);

  return (
    <div className="app-container">
      <aside className="branding-panel">
        <div className="logo-title">expert.<span className="logo-accent">ai</span></div>
        <p className="tagline">Your partner in hybrid AI for language understanding.</p>
        <div className="graphic-placeholder">[Visuals / Branding here]</div>
      </aside>

      <main className="chat-main">
        <div className="chat-window">
          {messages.map((msg, idx) => (
            <motion.div
              key={idx}
              className={\`chat-bubble \${msg.sender}\`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              {msg.text}
            </motion.div>
          ))}
          {showTyping && <div className="typing-indicator">...</div>}
        </div>

        {messages.length <= 2 && (
          <div className="quick-questions">
            {suggestedQuestions.map((q, i) => (
              <button key={i} className="quick-btn" onClick={() => handleSuggested(q)}>{q}</button>
            ))}
          </div>
        )}

        <div className="input-area">
          {!showLinkedIn ? (
            <>
              <input
                className="chat-input"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && input && handleSend(input)}
                placeholder="Ask me about expert.ai…"
              />
              <button className="send-btn" onClick={() => input && handleSend(input)}>Send</button>
            </>
          ) : (
            <button className="linkedin-btn">Log in with LinkedIn</button>
          )}
        </div>
      </main>
    </div>
  );
}
